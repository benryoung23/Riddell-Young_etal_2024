%Code for plotting the results of the 1 box model for HS4

clear all
close all

%Load CFA data
CFA = xlsread('Rhodes_CFA.xlsx');   %Rhodes et al., 2015
Depth = CFA(:,1);
GasAge = CFA(:,5);
CFA_CH4 = CFA(:,4);

%Load HS4 1 box model dataset
H4_1box = xlsread('H4_1boxR.xlsx');
GasAgeM = H4_1box(:,1);
C13Diff20I = H4_1box(:,2);
SbbSum20 = H4_1box(:,3);
SmicSum20 = H4_1box(:,4);
dD_CH4_Cff = H4_1box(:,5);
%dD_CH4_Cff = smooth(GasAgeM,dD_CH4_Cff,.01,'rloess');
fS20 = H4_1box(:,7);
micS20 = H4_1box(:,6);
dD_CH4_Cbb = H4_1box(:,8);
%dD_CH4_Cbb = smooth(GasAgeM,dD_CH4_Cbb,.01,'rloess');

%Load H4 C13 data
H4data = xlsread('H4_13C_Diff.xlsx');
H4MeanDepth = H4data(:,1) - 0.7375;          %subtract 0.7375m from depth because of replicate core offset (T.J. Fudge, personal comm)
H4C13Diff20 = H4data(:,5);
%Interpolate age
H4MeanAge = interp1(Depth,GasAge,H4MeanDepth);

%Load H4 dD
dDH4data = xlsread('H4_dD_Diff.xlsx');
dDH4MeanDepth = dDH4data(:,1) - 0.7375;          %Add 0.7375m to depth because of replicate core offset (T.J. Fudge, personal comm)
H4dDDiff20 = dDH4data(:,5);
%Interpolate age
dDH4MeanAge = interp1(Depth,GasAge,dDH4MeanDepth);
%Interpolate (gaussian) onto CFA age scale
dDH4GasAgeNew = [39160:1:39733]';
H4dDDiff20I = interp1(dDH4MeanAge,H4dDDiff20,dDH4GasAgeNew,'pchip');

% Load Talos Dome dD and CH4 and updated age scale
TD_Buizert = xlsread('TAL_age_Ben_BZT2018.xlsx'); 
TD_CH4 = xlsread('TD_CH4_Buiron2011_NewBern.xlsx');
TD_dD = xlsread('TD_dD_for_Ben.xlsx');
% Interpolate
TD_BZTage_dD = interp1(TD_Buizert(:,1),TD_Buizert(:,3),TD_dD(:,1));
TD_BZTage_CH4 = interp1(TD_Buizert(:,1),TD_Buizert(:,3),TD_CH4(:,1));

%% Load other isotope data
%13C data first
%Load Bock 2017 13C (age scale adusted 350 years to match data)
BockTaldice_data = xlsread('Bock2017_Taldice_C13.xlsx');
TAge = BockTaldice_data(:,2)*1000;
T13C = BockTaldice_data(:,11);
BockEDC_data = xlsread('EDC_13C.xlsx');
EDCAge = BockEDC_data(:,2);
EDC13C = BockEDC_data(:,7);
%Load Moller 2013
EDML_data = xlsread('EDML_13C.xlsx');
EDMLAge = EDML_data(:,2);
EDML13C = EDML_data(:,7);

%Now dD data 
%Bock Moller 2010
NGRIP_data = xlsread('Bock_NGRIP_dD.xlsx');
NGRIPAge = NGRIP_data(:,3);
NGRIPdD = NGRIP_data(:,6);
%Load Bock 2017
dDEDML_data = xlsread('Bock_EDML_dD_2017.xlsx');
dDEDMLAge = dDEDML_data(:,2)*1000;
dDEDML = dDEDML_data(:,6);
%Load Sowers 2006
Sowers_dD = xlsread('Sowers_2006_dD.xlsx');
SowersAge = Sowers_dD(:,2)*1000;
SowersdD = Sowers_dD(:,3);

%% Load data for other proxies

SpelN = csvread('Cheng_2016.csv',1,0);
SpelS = csvread('H4_brazil_wendt.csv',1,0);     %Only for Heinrich 4
CO2data = csvread('Bauska_CO2.csv',1,0);
NGRIP_O18data = csvread('NGRIP_18O.csv',1,0);
%Load Jons rIPD data
GISP2rIPD = csvread('DO8HS4rIPDforBen.csv',1,0);
%Create artificial greenland CH4 record
interpWDCCH4 = interp1(GasAge,CFA_CH4,GISP2rIPD(:,1));
GreenlandCH4 = interpWDCCH4.*(1+GISP2rIPD(:,4)/100);

%% plot! (Figure 1 of paper!) 

f = figure(3);
%f.Position = [1833 -110 500 1200]; %For computer monitor
f.Position = [100 100 500 800];
hold on
set(gcf,'Color','w');
ax = gca;
ax.XColor = 'None';
ax.YColor = 'None';
clear ax

%CFA CH4 record
box off
axes('Position',[.12, .80, .6, .19])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
plot (GasAge,CFA_CH4,'LineWidth',2,'Color','b');
hold on
xlim([37000 42000])
ylim([375 600])
ax.XColor = 'None';
ax.YColor = 'k';
%ylabel('[CH_4] (ppb)','FontSize',15)
set(gca,'FontSize',15)
% box off
% axes('Position',[.11, .85, .78, .13])
% set(gca,'Color','None')
% ax = gca;
% set (ax,'Xdir','reverse')
% hold on
% plot (NGRIP_O18data(10:3000,1),NGRIP_O18data(10:3000,2),'LineWidth',1.5)
% hold on
% xlim([37000 42000])
% ax.XColor = 'None';
% ylabel(['NGRIP \delta^1^8O_{ice} ( ',char(8240),')'],'FontSize',13)
% set(gca,'FontSize',13)
% 
% %CH4 CFA record
% box off
% axes('Position',[.11, .74, .78, .15])
% set(gca,'Color','None')
% ax = gca;
% set (ax,'Xdir','reverse')
% hold on
% yyaxis right
% plot (GasAge,CFA_CH4,'LineWidth',1.5);
% hold on
% xlim([37000 42000])
% ylim([375 600])
% ax.XColor = 'None';
% ax.YColor = 'k';
% ylabel('[CH_4] (ppb)','FontSize',13)
% set(gca,'FontSize',13)
% yyaxis left
% ax.YColor = 'None';

%13C-CH4 data
box off
axes('Position',[.12, .62, .6, .21])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
yyaxis right
hold on
a = plot (TAge,T13C,'LineStyle','-','Color',"#77AC30",'Marker','o','MarkerEdgeColor',"#77AC30",'LineWidth',.75);
hold on 
% scatter (EDCAge,EDC13C,'blue')
% hold on
b = plot (EDMLAge,EDML13C,'LineStyle','-','Color',"#EDB120",'Marker','o','MarkerEdgeColor',"#EDB120",'LineWidth',.75);
hold on 
plot (GasAgeM,C13Diff20I,'LineWidth',1,'Color','k','LineStyle','-');
hold on
c = plot (H4MeanAge,H4C13Diff20,'Marker','d','LineStyle','none','MarkerSize',7,'MarkerFaceColor',"#A2142F",'MarkerEdgeColor',"#A2142F");
hold on
xlim([37000 42000])
ax.XColor = 'None';
ax.YColor = 'k';
%legend([a b c],'Bock 2017','Möller 2013','This Study','Location','best','FontSize',12,'EdgeColor','none','Color','none')
%ylabel(['\delta^1^3C-CH_4 ( ',char(8240),')'],'FontSize',15)
set(gca,'FontSize',15)
yyaxis left
ax.YColor = 'None';

%BB
box off
axes('Position',[.12, .45, .6, .2])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
a = plot (GasAgeM,(SbbSum20),'LineStyle','-','LineWidth',2,'Color',"#A2142F");%./(SbbSum20+SmicSum20+30)))
hold on
jbfill(GasAgeM',(SbbSum20 + 2*H4_1box(:,10))',(SbbSum20 - 2*H4_1box(:,10))',[0.6350 0.0780 0.1840],'none');
hold on
%b = plot (GasAgeM,(fS20),'LineStyle','-','LineWidth',2,'Color',"#0072BD");%./(fS20+micS20+20)))
%hold on
xlim([37000 42000])
ylim([12 33])
ax.XColor = 'None';
ax.YColor = 'k';
%ylabel('BB (Tg yr^-^1)','FontSize',15)
set(gca,'FontSize',15)
%legend([a b],'BB','Geo','Location','west','FontSize',12,'EdgeColor','none','Color','none')

%Mic
box off
axes('Position',[.12, .33, .6, .18])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
yyaxis right
a = plot (GasAgeM,(SmicSum20),'LineStyle','-','LineWidth',2,'Color',"#77AC30");%./(SbbSum20+SmicSum20+30)))
hold on
jbfill(GasAgeM',(SmicSum20 + 2*H4_1box(:,10))',(SmicSum20 - 2*H4_1box(:,10))',[0.4660 0.6740 0.1880],'none');
hold on
%b = plot (GasAgeM,(micS20),'LineStyle','-.','LineWidth',2,'Color',"#77AC30");%./(fS20+micS20+20)))
%hold on
xlim([37000 42000])
ylim([70 120])
ax.XColor = 'None';
ax.YColor = 'k';
%ylabel('Mic (Tg yr^-^1)','FontSize',15)
set(gca,'FontSize',15)
%legend([a b],'Mic (const. Geo)','Mic (const. BB)','Location','west','FontSize',12,'EdgeColor','none','Color','none')
yyaxis left
ax.YColor = 'None';

% %dD data and theoretical dD for above modelling scenarios
% box off
% axes('Position',[.11, .41, .76, .17])
% set(gca,'Color','None')
% ax = gca;
% set (ax,'Xdir','reverse')
% hold on
% a = plot (NGRIPAge,(NGRIPdD+14),'LineStyle','-','Color','Blue','Marker','o','MarkerEdgeColor',"Blue",'LineWidth',.75);
% hold on 
% % scatter(dDEDMLAge,(dDEDML),'green','filled','^')
% % hold on 
% b = plot (SowersAge(40:46),(SowersdD(40:46)+14),'LineStyle','-','Color','k','Marker','o','MarkerEdgeColor','k','LineWidth',.75);
% hold on
% d = plot (GasAgeM(20:end),dD_CH4_Cff(20:end),'LineWidth',2.5,'Color',[0.6350 0.0780 0.1840 .3],'LineStyle','-');
% hold on 
% e = plot (GasAgeM(20:end),dD_CH4_Cbb(20:end),'LineWidth',2.5,'Color',[0 0.4470 0.7410 .3],'LineStyle','-');
% hold on 
% plot (dDH4GasAgeNew,H4dDDiff20I,'LineStyle','-','LineWidth',1,'Color','black','Marker','none');
% hold on
% c = plot (dDH4MeanAge,H4dDDiff20,'Marker','d','MarkerSize',7,'MarkerFaceColor',"#A2142F",'MarkerEdgeColor',"#A2142F",'LineStyle','None');
% hold on
% xlim([37000 42000])
% ylim([-85 -58])
% ax.XColor = 'None';
% ax.YColor = 'k';
% legend([a b c d e],'Bock 2010','Sowers 2010','This Study','Mdl (const. geo)','Mdl (const. BB)','This Study','Location','west','FontSize',12,'EdgeColor','none','Color','none')
% ylabel(['\deltaD-CH_4 ( ',char(8240),')'],'FontSize',13)
% set(gca,'FontSize',13)
% 
% % %CH4 rIPD record
% % box off
% % axes('Position',[.11, .3, .76, .11])
% % set(gca,'Color','None')
% % ax = gca;
% % set (ax,'Xdir','reverse')
% % hold on
% % yyaxis right
% % %Plot GISP2 data 
% % edge = 'k';
% % jbfill(GISP2rIPD(38:62,1)',(GISP2rIPD(38:62,2))',(GISP2rIPD(38:62,3))',[0.3010 0.7450 0.9330]);
% % hold on
% % plot(GISP2rIPD(38:62,1),GISP2rIPD(38:62,4),'k-','LineWidth',2);
% % hold on
% % jbfill(GISP2rIPD(21:34,1)',(GISP2rIPD(21:34,2))',(GISP2rIPD(21:34,3))',[0.3010 0.7450 0.9330]);
% % hold on
% % plot(GISP2rIPD(21:34,1),GISP2rIPD(21:34,4),'k-','LineWidth',2);
% % hold on
% % plot(GISP2rIPD(21:34,1),GISP2rIPD(21:34,2),'k-','LineWidth',.25);
% % hold on
% % plot(GISP2rIPD(21:34,1),GISP2rIPD(21:34,3),'k-','LineWidth',.25);
% % hold on
% % jbfill(GISP2rIPD(1:15,1)',(GISP2rIPD(1:15,2))',(GISP2rIPD(1:15,3))',[0.3010 0.7450 0.9330]);
% % hold on
% % plot(GISP2rIPD(1:15,1),GISP2rIPD(1:15,4),'k-','LineWidth',2);
% % hold on
% % plot(GISP2rIPD(1:15,1),GISP2rIPD(1:15,2),'k-','LineWidth',.25);
% % hold on
% % plot(GISP2rIPD(1:15,1),GISP2rIPD(1:15,3),'k-','LineWidth',.25);
% % hold on
% % ylabel('rIPD (%)','FontSize',13)
% % set(gca,'FontSize',13)
% % ax.YColor = 'k';
% % xlim([37000 42000])
% % ylim([-2 8])
% % plot([10000 50000],[0 0],'k--')
% % hold on
% % yyaxis left
% % ax.YColor = 'k';
% % ax.XColor = 'None';
% 
%Northern and southern speleothem data

box off
axes('Position',[.12, .16, .6, .16])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
yyaxis left
plot (SpelN(:,1)*1000,SpelN(:,2),'LineWidth',1.5,'Color',[.64 .35 .29])
hold on
ax.YColor = '[.64 .35 .29]';
%ylabel(['\delta^1^8O_{Hulu} ( ',char(8240),')'],'FontSize',15,'Color',[.64 .35 .29])
set(gca,'FontSize',15)
yyaxis right
set (ax,'Xdir','reverse')
plot (SpelS(:,1),SpelS(:,3),'LineWidth',1.5,'Color',[.37 .55 .24])
hold on
xlim([37000 42000])
ylim([-9 -1])
yticks([-8 -6 -4 -2])
ax.XColor = 'k';
ax.YColor = '[.37 .55 .24]';
%ylabel(['\delta^1^8O_{SAM} ( ',char(8240),')'],'FontSize',15,'Color',[.37 .55 .24])
xlabel('Age (Kyr BP)','FontSize',15)
set(gca,'FontSize',15)

% %CO2 data
% box off
% %axes('Position',[.11, .19, .76, .1])
% axes('Position',[.12, .41, .6, .17])
% set(gca,'Color','None')
% ax = gca;
% set (ax,'Xdir','reverse')
% hold on
% %yyaxis right
% plot (CO2data(:,2),CO2data(:,4),'LineWidth',1,'Color',"#7E2F8E",'Marker','o','MarkerEdgeColor',"#7E2F8E")
% hold on
% xlim([37000 42000])
% ylim([195 225])
% yticks([200 210 220])
% ax.XColor = 'k';
% ax.YColor = 'k';
% ylabel('[CO_2] (ppm)','FontSize',15)
% xlabel('Age (KaBP) on original age scales','FontSize',15)
% set(gca,'FontSize',15)
% % yyaxis left
% % ax.YColor = 'None';

%Label boxes 
annotation('textbox',[.125 .89 .1 .1],'String','(a)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
annotation('textbox',[.66 .73 .1 .1],'String','(b)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
annotation('textbox',[.125 .54 .1 .1],'String','(c)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
annotation('textbox',[.66 .41 .1 .1],'String','(d)','EdgeColor','none' ,'FontSize',17,'Color',[.3 .3 .3])
%annotation('textbox',[.115 .48 .1 .1],'String','(e)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
annotation('textbox',[.125 .23 .1 .1],'String','(e)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
%annotation('textbox',[.115 .30 .1 .1],'String','(f)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
%annotation('textbox',[.815 .20 .1 .1],'String','(g)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])

%Label climate intervals
annotation('textbox',[.14 .85 .1 .1],'String','DO 10','EdgeColor','none','FontSize',15,'FontWeight','bold','Color','k')
annotation('textbox',[.28 .85 .1 .1],'String','DO 9','EdgeColor','none','FontSize',15,'FontWeight','bold','Color','k')
annotation('textbox',[.58 .90 .1 .1],'String','DO 8','EdgeColor','none','FontSize',15,'FontWeight','bold','Color','k')


%% Plot dD data and modelling!

f = figure(5);
f.Position = [100 100 500 700];
hold on
set(gcf,'Color','w');
ax = gca;
ax.XColor = 'None';
ax.YColor = 'None';
clear ax

%CFA CH4 record
box off
axes('Position',[.13, .80, .74, .19])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
a = plot (GasAge,CFA_CH4,'LineWidth',2,'Color','b');
hold on
b = plot (TD_BZTage_CH4,TD_CH4(:,3),'LineWidth',1,'Color','m','Marker','o');
hold on 
xlim([37500 40800])
ylim([375 600])
ax.XColor = 'None';
ax.YColor = 'k';
ylabel('[CH_4] (ppb)','FontSize',15)
set(gca,'FontSize',15)
legend([a b],'WD CH_4','TD CH_4','Location','best','FontSize',12,'EdgeColor','none','Color','none')

%13C-CH4 data
box off
axes('Position',[.13, .67, .74, .17])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
yyaxis right
hold on
% a = plot (TAge,T13C,'LineStyle','-','Color',"#77AC30",'Marker','o','MarkerEdgeColor',"#77AC30",'LineWidth',.75);
% hold on 
% scatter (EDCAge,EDC13C,'blue')
% hold on
% b = plot (EDMLAge,EDML13C,'LineStyle','-','Color',"#EDB120",'Marker','o','MarkerEdgeColor',"#EDB120",'LineWidth',.75);
% hold on 
plot (GasAgeM,C13Diff20I,'LineWidth',1,'Color','k','LineStyle','-');
hold on
c = plot (H4MeanAge,H4C13Diff20,'Marker','d','LineStyle','none','MarkerSize',7,'MarkerFaceColor',"#A2142F",'MarkerEdgeColor',"#A2142F");
hold on
xlim([37500 40800])
ax.XColor = 'None';
ax.YColor = 'k';
%legend([a b c],'Bock 2017','Möller 2013','This Study','Location','best','FontSize',12,'EdgeColor','none','Color','none')
ylabel(['\delta^1^3C-CH_4 ( ',char(8240),')'],'FontSize',15)
set(gca,'FontSize',15)
yyaxis left
ax.YColor = 'None';

%Geologic assuming constant BB
box off
axes('Position',[.13, .53, .74, .19])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
% a = plot (GasAgeM,(SbbSum20),'LineStyle','-','LineWidth',2,'Color',"#A2142F");%./(SbbSum20+SmicSum20+30)))
% hold on
b = plot (GasAgeM,(fS20+7),'LineStyle','-','LineWidth',2,'Color',"#0072BD");%./(fS20+micS20+20)))
hold on
jbfill(GasAgeM',(fS20+7 + 2*H4_1box(:,12))',(fS20+7 - 2*H4_1box(:,12))',[0 0.4470 0.7410],'none');
hold on
xlim([37500 40800])
ylim([-5 35])
ax.XColor = 'None';
ax.YColor = 'k';
ylabel('\Delta Geo (Tg yr^-^1)','FontSize',15)
set(gca,'FontSize',15)
%legend([a b],'BB','Geo','Location','west','FontSize',12,'EdgeColor','none','Color','none')

%Mic
box off
axes('Position',[.13, .4, .74, .16])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
yyaxis right
% a = plot (GasAgeM,(SmicSum20),'LineStyle','-','LineWidth',2,'Color',"#77AC30");%./(SbbSum20+SmicSum20+30)))
% hold on
b = plot (GasAgeM,(micS20+10),'LineStyle','-','LineWidth',2,'Color',"#77AC30");%./(fS20+micS20+20)))
hold on
jbfill(GasAgeM',(micS20+10 + 2*H4_1box(:,11))',(micS20+10 - 2*H4_1box(:,11))',[0.4660 0.6740 0.1880],'none');
hold on
xlim([37500 40800])
ylim([-5 35])
ax.XColor = 'None';
ax.YColor = 'k';
ylabel('\Delta Mic (Tg yr^-^1)','FontSize',15)
set(gca,'FontSize',15)
%legend([a b],'Mic (const. Geo)','Mic (const. BB)','Location','west','FontSize',12,'EdgeColor','none','Color','none')
yyaxis left
ax.YColor = 'None';


%dD data and theoretical dD for above modelling scenarios
box off
axes('Position',[.13, .12, .74, .3])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
% plot (dDH4GasAgeNew,H4dDDiff20I,'LineWidth',1,'Color','k','LineStyle','-');
% hold on
c = plot (GasAgeM(20:end)/1000,dD_CH4_Cff(20:end),'LineWidth',2,'Color',"#A2142F",'LineStyle','-');
hold on 
d = plot (GasAgeM(20:end)/1000,dD_CH4_Cbb(20:end),'LineWidth',2,'Color',"#0072BD",'LineStyle','-');
hold on 
e = plot (dDH4MeanAge/1000,H4dDDiff20,'Marker','d','LineStyle','none','MarkerSize',7,'MarkerFaceColor','g','MarkerEdgeColor','k');
hold on
f = plot (TD_BZTage_dD(24:end)/1000,TD_dD((24:end),3),'Marker','d','LineStyle','none','MarkerSize',7,'MarkerFaceColor','m','MarkerEdgeColor','k');
hold on
xlim([37.5 40.8])
ylim([-84 -52])
legend([c d e f],'Mdl Stable Geo','Mdl Stable Pryo','WD','TALDICE','Location','best','FontSize',12,'EdgeColor','none','Color','none')
ax.XColor = 'k';
ylabel(['\deltaD-CH_4 ( ',char(8240),')'],'FontSize',15)
set(gca,'FontSize',15)
ax.YColor = 'k';
xlabel('Age (KaBP) on original age scales','FontSize',15)

%Label boxes 
annotation('textbox',[.13 .89 .1 .1],'String','(a)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
annotation('textbox',[.81 .74 .1 .1],'String','(b)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
annotation('textbox',[.13 .62 .1 .1],'String','(c)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
annotation('textbox',[.81 .465 .1 .1],'String','(d)','EdgeColor','none' ,'FontSize',17,'Color',[.3 .3 .3])
%annotation('textbox',[.115 .48 .1 .1],'String','(e)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
annotation('textbox',[.13 .32 .1 .1],'String','(e)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
%annotation('textbox',[.115 .30 .1 .1],'String','(f)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
%annotation('textbox',[.815 .20 .1 .1],'String','(g)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])

%Label climate intervals
annotation('textbox',[.20 .85 .1 .1],'String','DO 9','EdgeColor','none','FontSize',15,'FontWeight','bold','Color','k')
%annotation('textbox',[.30 .85 .1 .1],'String','DO 9','EdgeColor','none','FontSize',15,'FontWeight','bold','Color','k')
annotation('textbox',[.73 .90 .1 .1],'String','DO 8','EdgeColor','none','FontSize',15,'FontWeight','bold','Color','k')
annotation('line',[.415 .415],[.17 .99],'Color','k','LineStyle','--');